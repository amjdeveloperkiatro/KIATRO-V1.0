const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6288228968298"
global.NamaBot = "KiatroBot"
global.nama = "𝙺𝚎𝚛𝚣𝚣𝚡𝙳𝚎𝚟"
global.ch = 'https://whatsapp.com/channel/0029VawpWkO3GJOsF2Gtj60v'
global.status = true
//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "Tidak Tersedia"
global.ovo = "Tidak Tersedia"
global.qris = "Tidak Tersedia"
//====== [ THEME URL & URL ] ========//
global.thumb = fs.readFileSync('./kerzz.jpg'); // Buffer Image
global.thumbnail = 'https://img1.pixhost.to/images/5688/597663440_imgtmp.jpg'
global.Url = '-'
global.logodana = "https://img100.pixhost.to/images/667/540082364_skyzopedia.jpg", 
global.logoovo = "https://img100.pixhost.to/images/667/540082774_skyzopedia.jpg", 

global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat"
}

global.packname = 'KiatroBoy'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

global.pairing = "KERZOFFC"

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
